# Something Gamer — recuperação para VS Code

Pacote reconstruído em 04/11/2026 a partir do commit ab6d3dbf61e3208d92fc87ff286ca7f8d6f58595 do repositório privado Gabomgames/SG. O ZIP original de 27,36 MB não estava disponível nesta tarefa; este arquivo não é uma cópia byte a byte dele.

Inclui todos os 556 arquivos versionados, frontend, backend Cloudflare em something-gamer-api/, Firebase Functions em functions/, documentação, scripts, testes, wrappers existentes, build em dist/ e SG-ab6d3db.bundle com histórico completo. node_modules e credenciais não são incluídos. As configurações públicas versionadas são preservadas. Não contém arquivos .env reais.

## Abrir e executar

Extraia o ZIP e abra a pasta principal no VS Code. Use Node 24.19.0 (conforme .node-version) para a raiz. No terminal PowerShell:

```powershell
code .
npm.cmd ci --no-audit --no-fund
npm.cmd run dev
```

Abra http://localhost:5173. Não abra os HTML pelo protocolo file://. O servidor local entrega o frontend; autenticação, dados e serviços externos dependem da configuração e dos acessos existentes. Não há credenciais de produção neste pacote. Não execute comandos deploy para experimentar localmente.

Para refazer o build: `npm.cmd run build`. O build incluído está em dist/. O arquivo .local/admin-route.json registra o caminho administrativo gerado por este build; esse caminho não substitui autenticação/autorização.

O backend Worker mantém seu comando dev existente: `npx.cmd wrangler dev --config something-gamer-api/wrangler.jsonc`, a partir da raiz após npm ci. Use somente recursos locais de teste. Para as Functions, use Node 20.20.2 e `npm.cmd ci --prefix functions --no-audit --no-fund`. Consulte docs/phase1/acceptance-d7c8a14/WINDOWS-VSCODE.md para os procedimentos de validação com demo-sg. Windows não foi executado nesta tarefa.

## Restaurar o Git offline

Na pasta que contém o bundle, clone para uma pasta nova:

```powershell
git clone --branch recovery SG-ab6d3db.bundle SG-com-historico
git -C SG-com-historico fsck --full
git -C SG-com-historico rev-parse HEAD
```

O HEAD deve ser ab6d3dbf61e3208d92fc87ff286ca7f8d6f58595. O clone contém os fontes; dist/ pode ser reconstruído ou copiado deste pacote. A branch recovery é uma referência local do bundle, sem mudança de branch remota.

## Verificações desta recuperação

Instalação npm ci, verificador (418 arquivos), build e 73 testes da suíte npm test passaram. O bundle foi verificado, clonado em outra pasta e passou por git fsck. Os arquivos versionados foram comparados byte a byte com o commit. A varredura de padrões conhecidos de segredos em 556 arquivos/567 blobs históricos encontrou zero ocorrências; isso não é uma auditoria completa de segurança.

A integridade de cada arquivo é registrada em RECUPERACAO/SHA256.json. O SHA-256 do ZIP é publicado separadamente na Release. Nenhum código foi alterado nesta recuperação. A Fase 1 permanece com as pendências documentadas no repositório. Esta entrega não aprova a Fase 1, não inicia a Fase 2 e não realiza deploy ou ativação de produção.
